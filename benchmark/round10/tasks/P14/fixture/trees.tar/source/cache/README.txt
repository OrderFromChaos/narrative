This directory holds cached tiles.
